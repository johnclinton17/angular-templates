/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * otp.component.ts
 * Description: import all modules and routing 
 * Copyright (c) 2019 aegonlife Insurance
 */

//import all dependency file for building app
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng2FabSpeedDialModule} from 'ng2-fab-speed-dial';
import { MzNavbarModule, MzSidenavModule, MzButtonModule, MzDropdownModule, MzCardModule, MzBadgeModule, MzCheckboxModule, MzTextareaModule, MzSelectModule, MzDatepickerModule   } from 'ngx-materialize';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { OtpComponent } from './otp/otp.component';
import { ApiService } from './api/api.service';
import { ResponsiveService } from './responsive.service';
import { LottieAnimationViewModule } from 'ng-lottie';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { HomeComponent } from './home/home.component';
import { MzModalModule } from 'ngx-materialize';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SurrenderPolicyComponent } from './surrender-policy/surrender-policy.component';
import { NomineeComponent } from './nominee/nominee.component';
import { AngularDraggableModule } from 'angular2-draggable';
import { AuthGuard } from './auth.guard';
import { SupportComponent } from './support/support.component';
import { TrackRequestComponent } from './track-request/track-request.component';
import { LoginComponent } from './login/login.component';
import { AddPolicyComponent } from './add-policy/add-policy.component';
import { DesktopLoginComponent } from './desktop-login/desktop-login.component';
import { DesktophomeComponent } from './desktophome/desktophome.component';


//create routing for all user pages
const Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent, data: { depth: 'login' } },
  { path: 'otp', component: OtpComponent, data: { depth: 'otp' } },
  { path: 'addpolicy', component: AddPolicyComponent , canActivate: [AuthGuard]  ,  data: {depth: 'addploicy'} },
  { path: 'home', component: HomeComponent  ,  data: {depth: 'home'} },
  { path: 'updateaccountinfo', component: UpdateAccountComponent ,   canActivate: [AuthGuard] , data: {depth: 'updateaccount'} },
  { path: 'updateprofile/:pageType', component: UpdateProfileComponent ,  canActivate: [AuthGuard] ,  data: {depth: 'profile'} },
  { path: 'feedback', component: FeedbackComponent ,  canActivate: [AuthGuard] ,  data: {depth: 'feedback'} },
  { path: 'nominee', component: NomineeComponent ,   canActivate: [AuthGuard] , data: {depth: 'nominee'} },
  { path: 'surrenderpolicy', component: SurrenderPolicyComponent ,  canActivate: [AuthGuard] ,  data: {depth: 'surrender'} },
  { path: 'support', component: SupportComponent ,  canActivate: [AuthGuard] ,  data: {depth: 'support'} },
  { path: 'trackrequest', component: TrackRequestComponent ,  canActivate: [AuthGuard] ,  data: {depth: 'track'} },
 ]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    OtpComponent,
    HomeComponent,
    UpdateAccountComponent,
    UpdateProfileComponent,
    FeedbackComponent,
    SurrenderPolicyComponent,
    NomineeComponent,
    SupportComponent,
    TrackRequestComponent,
    LoginComponent,
    AddPolicyComponent,
    DesktopLoginComponent,
    DesktophomeComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(Routes, {scrollPositionRestoration: 'top'}), 
     HttpModule,
     HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    Ng2FabSpeedDialModule,
    MzNavbarModule,
    MzSidenavModule,
    MzButtonModule,
    MzTextareaModule,
    MzDropdownModule,
    MzCardModule,
    MzCheckboxModule ,
    MzDatepickerModule,
    MzSelectModule ,
    MzModalModule,
    MzBadgeModule,
    FormsModule,
    SlickCarouselModule,
    AngularDraggableModule,
    LottieAnimationViewModule.forRoot(),
    ServiceWorkerModule.register('../ngsw-worker.js', { enabled: environment.production })
    
  ],
  providers: [ResponsiveService],
  bootstrap: [AppComponent]
})
export class AppModule { }
