//import all dependency file for initiate service
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable, Subject, ReplaySubject, from, of, range } from 'rxjs';
import { map, filter, switchMap, catchError,retry} from 'rxjs/operators';
import * as CryptoJS from 'crypto-js';
@Injectable({
  providedIn: 'root'
})

export class ApiService {

constructor(private _http: Http) { }
 apiUrl = "http://192.168.1.37:5000"
//service requestion api
apirequest(url, params) {
   var expirationMS = 350 * 60 * 1000;

        var record = { value: JSON.stringify('expiry'), timestamp: new Date().getTime() + expirationMS }
        localStorage.setItem('expirecheck', JSON.stringify(record));
        
    return this._http.post(this.apiUrl+"/"+url, params).pipe(map(res => res),catchError(err => {
              return of(null);
          })
    );
  }

  getRequest(url): Observable<any> {
  return this._http.get(url).pipe(
    map(res=>res),catchError(err => {
              return of(null);
          }));
}



// encryp and decrypt

 set(keys, value){
    var key = CryptoJS.enc.Utf8.parse(keys);
    var iv = CryptoJS.enc.Utf8.parse(keys);
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(value.toString()), key,
    {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });

    return encrypted.toString();
  }

  //The get method is use for decrypt the value.
  get(keys, value){
    var key = CryptoJS.enc.Utf8.parse(keys);
    var iv = CryptoJS.enc.Utf8.parse(keys);
    var decrypted = CryptoJS.AES.decrypt(value, key, {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });

    return decrypted.toString(CryptoJS.enc.Utf8);
  }

}
