/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * nominee.component.ts
 * Description: to add and update to nominee
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-nominee',
  templateUrl: './nominee.component.html',
  styleUrls: ['./nominee.component.css']
})
export class NomineeComponent implements OnInit {

  constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router) { }
 dateOfBirth : any;

  ngOnInit() {

  
  }
}
