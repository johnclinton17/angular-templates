/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * surrender.component.ts
 * Description: surrender Policy
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit, AfterViewInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { Router, RouterModule, ActivatedRoute, NavigationStart } from '@angular/router';
import { ResponsiveService } from '../responsive.service';
import { ApiService } from './../api/api.service';
import * as moment from 'moment';
declare let $: any;
@Component({
  selector: 'app-surrender-policy',
  templateUrl: './surrender-policy.component.html',
  styleUrls: ['./surrender-policy.component.css']
})
export class SurrenderPolicyComponent implements OnInit {
  inBounds = true;
  position;
  edge = {
    top: true,
    bottom: true,
    left: true,
    right: true
  };
  userDetails: any;
  mobileNo : number;
  emailId : string;
  firstName : string;
  lastName : string;
  name : string;
  policyDetail: any;
  policyName : string;
  policynum : string;
  sumAssured : string;
  data: any;
  difference: any;
  freelookPeriod : string;
  bottomflag = true;
  @ViewChild("block", { read: ElementRef }) block: ElementRef;
  @HostListener('touchmove', ['$event'])
  handleWheelEvent(event) {
    event.preventDefault();
  }
  constructor(private ApiService: ApiService, route: ActivatedRoute, private router: Router, private responsiveService: ResponsiveService) {
  }
  ngOnInit() {
   
    this.userDetails = {};
    this.policyDetail = {};
    let decrypted = this.ApiService.get(localStorage.getItem('policynum'));
    this.policynum = decrypted;
    this.ApiService.apirequest('getPolicyBypolicyNumber', { "policyNumber": this.policynum, "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken  }).subscribe(data => {
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.policyDetail = data.json();
        let partyid = this.policyDetail.insured.id;
        let before = moment(this.policyDetail.issueDate);
        let now = moment();
        this.difference = moment(<any>now - <any>before).format('D');
        this.freelookPeriod = this.policyDetail.freelookPeriod;
        this.sumAssured = this.policyDetail.coverages[0].sumAssured || '';
        this.getDetails(partyid);
        this.policyName = this.policyDetail.product.name;
      }
    }, err => { this.router.navigate(['/login']); })
  }
  getDetails(partyid): void {
    this.ApiService.apirequest('getuserCardDetails', { "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken , "partyid": partyid }).subscribe(data => {
      this.userDetails = data.json();
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.userDetails = data.json();

        this.firstName = this.userDetails.firstName;
        this.lastName = this.userDetails.lastName;
        this.mobileNo = this.findandReplaceMobileNumber(this.userDetails.contacts[0].contactInfo);
        this.emailId = this.findandReplaceEmail(this.userDetails.contacts[1].contactInfo);

        if (this.userDetails.lastName != null) {

          this.name = this.userDetails.firstName + ' ' + this.userDetails.lastName;
        } else {
          this.name = this.userDetails.firstName;
        }
      }
    }, err => { this.router.navigate(['/login']); })
  }
  // To xxx-xxx-xx mobile number
  findandReplaceMobileNumber(str) {
    let res = str.substring(2, 8);
    res = str.replace(res, "XXX XXX")
    return res;
  }
  // To xxx-xxx-xx email 
  findandReplaceEmail(str) {
    let res = str.substring(2, str.indexOf('@'));
    res = str.replace(res, "XXXXXXX")
    return res;
  }
  success(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  // adding and removing class to card
  addClass() : void{
    document.getElementById('textpara').classList.add("mystyle");
  }
  removeClass(): void  {
    document.getElementById('textpara').classList.remove("mystyle");
  }
   // adding and removing class to card
  // Get the modal
  // When the user clicks the button, open the modal 
  openAlert(): void {
    let modal = document.getElementById("myModal");
    modal.style.display = "block";
  }
  // When the user clicks on <span> (x), close the modal
  closeAlert(): void {
    let modal = document.getElementById("myModal");
    modal.style.display = "none";
  }
  // surrender error alert
  erroropenAlert(): void {
    let errormodal = document.getElementById("myModalError");
    errormodal.style.display = "block";
  }
  errorcloseAlert(): void {
    let errormodal = document.getElementById("myModalError");
    errormodal.style.display = "none";
  }
  // resetting the card
  cardReset(): void {
    this.position = { x: 0, y: 0 }
    this.chagnedetected = true;
    this.closeAlert();
    $(".hide-move-div h5, .hide-when-slide").css({ "opacity": "1", "transition": ".5s linear" });
  }
  // deleting the card
  deleteCard(): void {
    this.closeAlert();
    $(".swipe-card").css({ "transform": "translate(0 ,1000px)", "transition": "5s linear" });
    $(".animation-circle-ripples").addClass("animate");
    $(".hidden-text-layer").css({ "opacity": "1", "transition": ".5s linear" });
    var today = new Date();
    let obj = {
      "comment": "string",
      "reason": "FINANCIAL_DIFFICULTY", // Predefined Reasons forcancellation
      "requestedOn": today,
     "token": this.ApiService.getaccessToken().token, 
     "accessToken" :  this.ApiService.getaccessToken().accessToken , 
      "policynumber": this.policynum
    }
    this.ApiService.apirequest('freelookPolicy', obj).subscribe(data => {
      if (data.json().code) {
        localStorage.setItem('message', data.json().desc);
        this.success(3000).then(() => { this.router.navigate(['/feedback']); });
      }
      else {
        this.erroropenAlert();
        this.router.navigate(['/home']);
      }
    })
  }
  // card bottom event
  chagnedetected : boolean = false;
  checkEdge(event): void {
    this.edge = event;
    if (event.bottom == false) {
      this.chagnedetected = false;
      this.openAlert();
      $(".hide-move-div h5,.hide-when-slide").css({ "opacity": "0", "transition": ".5s linear" });
    }
    else {
      this.chagnedetected = true;
      this.closeAlert();
    }
  }

}
