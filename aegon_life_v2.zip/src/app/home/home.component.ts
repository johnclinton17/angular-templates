/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * home.component.ts
 * Description: Home screen with user details and policy details
 * Copyright (c) 2019 aegonlife Insurance
 */


import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 private ngNavigatorShareService: NgNavigatorShareService;
  constructor(private ApiService: ApiService, private router: Router) {  }

userDetails :any;
mobileNo;
emailId;
firstName ;
lastName;
name;
policyDetail;
policyName;
slides=[];
token;
policynum;
sumAssured;
  ngOnInit() {
 this.token=localStorage.getItem('token');
this.userDetails={};
 var decrypted = this.ApiService.get('123456$#@$^@1ERF', localStorage.getItem('policynum'));
this.policynum = decrypted;
this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": this.policynum,"token" : this.token}).subscribe(data => {
       if(data.json().statusCode){
        this.router.navigate(['/login']); 
       }else{

        this.policyDetail = data.json();
         let partyid = this.policyDetail.insured.id;
         this.sumAssured = this.policyDetail.coverages[0].sumAssured || '';
console.log(this.sumAssured);
this.getDetails(partyid);
      
    
        this.slides.push(this.policyDetail)
        this.policyName = this.policyDetail.product.name;
      }
    },err => {console.error(err);})



}


// share the view policy doc
sharePolicy(){
    this.ngNavigatorShareService.share({
      title: 'My Awesome app',
      text: 'hey check out my Share button',
      url: 'https://developers.google.com/web'
    }).then( (response) => {
      console.log(response);
    })
    .catch( (error) => {
      console.log(error);
    });
  
}


  // To xxx-xxx-xx mobile number

findandReplaceMobileNumber(str){
  var res = str.substring(2, 8);
  res=str.replace(res, "XXX XXX")
  return res;
}
// clear the localStroage 
  clearstorage(){   
  localStorage.setItem('addnominee', 'false')
  }

 // To xxx-xxx-xx email 
  findandReplaceEmail(str){
  var res = str.substring(2, str.indexOf('@'));
  res=str.replace(res, "XXXXXXX")
  return res;
  }

// get Deails of users
getDetails(partyid) {
     this.ApiService.apirequest('getuserCardDetails',{"token" : this.token ,"partyid" : partyid}).subscribe(data => {
  this.userDetails = data.json();
    
        console.log(data.json());
      if(data.json().statusCode){
        this.router.navigate(['/login']); 
       }else{
        this.userDetails = data.json();
        this.firstName = this.userDetails.firstName;
        this.lastName = this.userDetails.lastName;
        this.mobileNo = this.findandReplaceMobileNumber(this.userDetails.contacts[0].contactInfo);
        this.emailId =this.findandReplaceEmail(this.userDetails.contacts[1].contactInfo);

        if(this.userDetails.lastName != null){

         this.name = this.userDetails.firstName + ' ' + this.userDetails.lastName;
        }else{
           this.name = this.userDetails.firstName;
        }
        var encypted =this.ApiService.set('123456$#@$^@1ERF', this.name);
        localStorage.setItem('userDetails', encypted);
        

       }
    },err => {console.error(err);})
    }


}
