/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * nominee.component.ts
 * Description: to add and update to nominee
 * Copyright (c) 2019 aegonlife Insurance
 */


import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-nominee',
  templateUrl: './nominee.component.html',
  styleUrls: ['./nominee.component.css']
})
export class NomineeComponent implements OnInit {

constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router) { }
  // addednomineeFlag = false ;   
  // nomineeFlag ;
  // policyDeatil : any;
  // policyName;
  // clientName;
  // nominees = [];
  public options: Pickadate.DateOptions = {
  format: 'dddd, dd mmm, yyyy',
  formatSubmit: 'yyyy-mm-dd',
  selectYears: 12,
  
today: ''
};

public dateOfBirth = '1991-08-12';
  ngOnInit() {

//   	this.nomineeFlag = 'false';
//   	if(localStorage.getItem('addnominee')){
// this.nomineeFlag = localStorage.getItem('addnominee');
//   	}

//   this.policyDeatil={};
// this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": "GS5574445251941"}).subscribe(data => {
//         this.policyDeatil = data.json();
//         //  this.policyName = this.policyDeatil.product.name;
//         this.nominees = this.policyDeatil.nominees;
//     })

//   var decrypted = this.ApiService.get('123456$#@$^@1ERF', localStorage.getItem('userDetails'));
// this.clientName = decrypted;
   }

 


}
