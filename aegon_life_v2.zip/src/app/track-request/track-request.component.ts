import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-request',
  templateUrl: './track-request.component.html',
  styleUrls: ['./track-request.component.css']
})
export class TrackRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
