/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * update-profile.component.ts
 * Description: update the email and contact number
 * Copyright (c) 2019 aegonlife Insurance
 */
// import packages
import { Component, OnInit ,Renderer2} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  // veriable declearation
  public lottieConfig: Object;
  public lottieConfigSuccess: Object;
  private anim: any;
  private newanim: any;
  pagetype: string;
  userDetails:any;
  otpFlag:boolean = false;
  mobileNo:string;
  emailId: string;
  addresses : Object = {}
  email_id: string;
  mobile_no: any;
  addressLine1: string;
  addressLine2: string;
  cityname: string;
  statename: string;
  pincode: string;
  errorFlag :boolean = false;
  errorNumberFlag= false;
  dispOtp: string;
  otpText: string;
  updateObj= {
    "email":  '',
    "mobile": '',
    "token":''
  };
  

constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router, private renderer: Renderer2) {
  // animation configs
  this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/input-tick.json', false);
  this.lottieConfigSuccess = this.ApiService.animationConfig('assets/icons/animation-json/1708-success.json', false);

}

// handle animation
  handleAnimation(anim: any): void  {
    this.anim = anim;
  }
  handleOtpAnimation(newanim: any): void  {
    this.newanim = newanim;

  }

// play aniamtion
  successAnimation(): void  {
    this.newanim.play();
  }

// To check 10 digits and showing check animation
  textMobile(evernt : any): void {
    var target = event.srcElement;
    if(this.mobile_no){

  var textLength = this.mobile_no.length;
    }
  
  if(textLength === 10){
    this.anim.play();

    
  }
  else{
    this.anim.stop();
  };
  }



ngOnInit() {

  this.updateObj.token = this.ApiService.getaccessToken().token;
 this.route.params.subscribe(params => {
  this.pagetype = params['pageType'];
});

// get user deatails 
  this.ApiService.apirequest('getuserCardDetails',{"token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken  ,"partyid" : '3c8c119d-793f-42e5-a3d3-c4a2ba3e561c'}).subscribe(data => {
  this.userDetails = data.json();
        this.userDetails.contacts.forEach(val=>{
          if(val.contactType == "EMAIL"){

            this.emailId =val.contactInfo;
          }
          if(val.contactType == "MOBILE"){

            this.mobileNo = val.contactInfo;
          }
          
        })
        this.addresses = this.userDetails.addresses[0];
        
      })

}

//  check for only numbers
 onlyNumber(event): boolean {
  return this.ApiService.onlyNumber(event);
  }
  



// on key up send otp

 onKey(event:any): void  { 
     var target = event.srcElement;
     var textLength = target.value.length;
     // decrypt the OTP
     var decryptedOtp = this.ApiService.get( localStorage.getItem('mobileOtp'));
    if(textLength == 4 && target.value === decryptedOtp ){
      document.getElementById('partitioned').blur();

 this.ApiService.apirequest('getUpdateMobileNumber',this.updateObj).subscribe(data => {
   if(data.status == 200){
  
        this.newanim.play();
        this.ApiService.destroySuccess(3000).then(() => {  this.router.navigate(['/feedback']);});
  }
  })      
    } 
    else{
      if(textLength == 4){
        
      this.errorFlag = true;
        this.ApiService.destroySuccess(3000).then(() => {  this.errorFlag=false;});
      }
    }

  }



//  check for numeric
isInt(value) {
  var er = /^-?[0-9]+$/;
  return er.test(value);
}

// to send otp on mobile and email
sendOTP(mobile_email,type): void  {
  
  if(type=='mobile'){
  if(this.isInt(mobile_email)){
    if(mobile_email.length){
      this.ApiService.apirequest('OTPlogin', {number:mobile_email}).subscribe(data => {
        this.dispOtp = data.json().message;
         var encyptedOtp =this.ApiService.set(this.dispOtp);
        localStorage.setItem('mobileOtp',encyptedOtp)
        if(data.json().status){
          this.otpFlag = true;
          this.updateObj.mobile = mobile_email;
          this.updateObj.email = this.emailId;
        }
        else{
          this.errorNumberFlag = true;
          this.ApiService.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
        }
      },err => {
       this.errorNumberFlag = true;
       this.ApiService.destroySuccess(3000).then(() => {this.errorNumberFlag = false;}); 
     })
    }
  }else{
    this.errorNumberFlag = true;
    this.ApiService.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
  }
  }


  if(type =='email'){
if(mobile_email){
      this.ApiService.apirequest('OTPlogin', {number:mobile_email}).subscribe(data => {
        this.dispOtp = data.json().message;
         var encyptedOtp =this.ApiService.set( this.dispOtp);
        localStorage.setItem('mobileOtp',encyptedOtp)
        if(data.json().status){
          this.otpFlag = true;
           this.updateObj.mobile = this.mobileNo;
          this.updateObj.email = mobile_email;
        }
        else{
          this.errorNumberFlag = true;
          this.ApiService.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
        }
      },err => {
       this.errorNumberFlag = true;
       this.ApiService.destroySuccess(3000).then(() => {this.errorNumberFlag = false;}); 
     })
    }
  }
}






}
