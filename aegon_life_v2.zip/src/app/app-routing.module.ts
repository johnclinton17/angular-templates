/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * routing.ts
 * Description: to route between pages
 * Copyright (c) 2019 aegonlife Insurance
 */
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes, {scrollPositionRestoration: 'top', })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
