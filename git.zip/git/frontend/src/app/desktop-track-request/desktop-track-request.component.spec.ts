import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesktopTrackRequestComponent } from './desktop-track-request.component';

describe('DesktopTrackRequestComponent', () => {
  let component: DesktopTrackRequestComponent;
  let fixture: ComponentFixture<DesktopTrackRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesktopTrackRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesktopTrackRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
