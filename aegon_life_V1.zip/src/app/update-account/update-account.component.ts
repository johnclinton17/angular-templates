import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit {

  constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router) { }
clientName;
policyDeatil : any;
policyName;
  ngOnInit() {
    this.policyDeatil={};
this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": "GS5574445251941"}).subscribe(data => {
        console.log(data.json());
        this.policyDeatil = data.json();
        this.policyName = this.policyDeatil.product.name;
    })

  var decrypted = this.ApiService.get('123456$#@$^@1ERF', localStorage.getItem('userDetails'));
  console.log(decrypted);
this.clientName = decrypted;
  }

neviagteToProfile(type){
	this.router.navigate(['/updateProfile',type]);
}



}
