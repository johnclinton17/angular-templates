import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnominee',
  templateUrl: './addnominee.component.html',
  styleUrls: ['./addnominee.component.css']
})
export class AddnomineeComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

  addnominee() {
    localStorage.setItem('addnominee', 'true')
  }
}
