/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * app.component.ts
 * Description: router animation
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, Renderer2 } from '@angular/core';
import { ApiService } from './api/api.service'
import { Router, RouterModule, ActivatedRoute, NavigationStart } from '@angular/router';
import { trigger, transition, group, query, style, animate } from '@angular/animations';
import { SwUpdate } from '@angular/service-worker';
declare var window : any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('routeAnimation', [
          transition('home => updateaccount,home => profile ,updateaccount => profile , profile => feedback, home => surrender, home => nominee,nominee => profile', [
            style({ height: '!' }),
            query(':enter', style({ transform: 'translateX(100%)' })),
            query(':enter, :leave', style({ position: 'absolute', top: 0, left: 0, right: 0 })),
            // animate the leave page away
            group([
                query(':leave', [
                    animate('.300s ease', style({ transform: 'translateX(-100%)' })),
                ]),
                // and now reveal the enter
                query(':enter', animate('.300s ease', style({ transform: 'translateX(0)' }))),
            ]),
        ]),
          transition('profile=> updateaccount, profile=> home, updateaccount => home, feedback => profile,nominee => home ,surrender => home, profile => nominee',[
            style({ height: '!' }),
            query(':enter', style({ transform: 'translateX(-100%)' })),
            query(':enter, :leave', style({ position: 'absolute', top: 0, left: 0, right: 0 })),
            // animate the leave page away
            group([
                query(':leave', [
                    animate('.300s ease', style({ transform: 'translateX(100%)' })),
                ]),
                // and now reveal the enter
                query(':enter', animate('.300s ease', style({ transform: 'translateX(0)' }))),
            ]),
        ]),
    ])
]
})
export class AppComponent {
    previousUrl='';
    getDepth(outlet) {
        return outlet.activatedRouteData['depth'];
    }
    
    constructor(private renderer: Renderer2, private router: Router, private swUpdate: SwUpdate) {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    if (this.previousUrl) {
                        this.renderer.removeClass(document.body, this.previousUrl);
                    }
                    let currentUrlSlug ='';
                         currentUrlSlug = event.url.slice(1)
                    if (currentUrlSlug) {
                        // console.log(currentUrlSlug);
                        // console.log('previous',this.previousUrl);
                        var str = currentUrlSlug.replace('/' , '')
                        if(this.previousUrl){


                        var prestr = this.previousUrl.replace('/' , '')
                        this.renderer.removeClass(document.body, prestr);
                    }
                        this.renderer.addClass(document.body, str);
                    }
                    this.previousUrl = currentUrlSlug;
                }
            });
    
    }

    ngOnInit() {

        this.swUpdate.available.subscribe(evt => {
            if (window.confirm('New version available.Update to new version')) {
                window.location.reload();
            }   
        }
    )}

}

