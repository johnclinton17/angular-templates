import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesktophomeComponent } from './desktophome.component';

describe('DesktophomeComponent', () => {
  let component: DesktophomeComponent;
  let fixture: ComponentFixture<DesktophomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesktophomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesktophomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
