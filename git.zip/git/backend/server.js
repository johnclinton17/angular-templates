const express = require('express');
const bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var compression = require('compression');
const path = require('path');
const http = require('http');
const app = express();
var https = require('https');
var session = require('express-session');
var port = process.env.port || 5000;
const api = require('./api/app');
app.use(session({ resave: false, saveUninitialized: true, cookie: { secure: false, path: "/", httpOnly: false }, secret: 'AegonL1Fe@123', maxAge: 3600000 }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(compression());
// CORS Headers
app.use(function (req, res, next) {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,Content-Type');
	res.setHeader('Access-Control-Allow-Credentials', true);
	next();
});

app.use('/', api);

var options = {
};

http.createServer(app).listen(port);
//https.createServer(options, app).listen(5000);
console.log('started');
