/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * addnominee.component.ts
 * Description: Add Nominee detials
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnominee',
  templateUrl: './addnominee.component.html',
  styleUrls: ['./addnominee.component.css']
})
export class AddnomineeComponent implements OnInit {
  //  date picker code
  public datepickerOptions: Pickadate.DateOptions = {
    clear: 'Clear', // Clear button text
    close: 'Ok',    // Ok button text
    today: 'Today', // Today button text
    closeOnClear: true,
    closeOnSelect: false,
    format: 'dddd, dd mmm, yyyy', // Visible date format (defaulted to formatSubmit if provided otherwise 'd mmmm, yyyy')
    formatSubmit: 'yyyy-mm-dd',   // Return value format (used to set/get value)
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 100,    // Creates a dropdown of 10 years to control year,
  };

 
  

  constructor() { }

  ngOnInit() {

  }

  addnominee() {
    localStorage.setItem('addnominee', 'true')
  }
}
