
/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * add-policy.component.ts
 * Description: enter the policy number to see it's details
 * Copyright (c) 2019 aegonlife Insurance
 */



import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-policy',
  templateUrl: './add-policy.component.html',
  styleUrls: ['./add-policy.component.css']
})
export class AddPolicyComponent implements OnInit {

  constructor(private ApiService: ApiService, private router: Router) { }
  // varaible declearation
  userDetails: any;
  day : any;
  month : any;
  year : any;
  policyNumber:any;
  prolicyDetail : any;
  errorFlag :boolean;
 
  ngOnInit() {
  this.errorFlag = false;
    
  }
  // get policy datetail
  getPolciy() {
    this.ApiService.apirequest('getPolicyBypolicyNumber', { "policyNumber": this.policyNumber, "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken }).subscribe(data => {
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        
        this.prolicyDetail = data.json();
        let encypted = this.ApiService.set(this.policyNumber);
        localStorage.setItem('policynum', encypted);
        let partyid = this.prolicyDetail.insured.id;
        this.userDetail(partyid) //pass the partyid to get details of user 
      }
    })
  }
  // get user details
  userDetail(partyid){
    this.ApiService.apirequest('getuserCardDetails', {  "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken , "partyid": partyid }).subscribe(data => {
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.userDetails = data.json();
        let dob = this.userDetails.dateOfBirth;
        this.compareDate(dob);
      }
    })

  }
  

  // switch focus of textbox
  validatePassKey(event: any, id, length): void {
    var target = event.srcElement;
    var textLength = target.value.length;
    if (textLength >= length) {
      document.getElementById(id + 1).focus();
    }
  }
  // compare the date of birth of user
  compareDate(dob) {
    var clienDob = new Date(dob);
    let dobdate = clienDob.getDate();
    let dobMonth = clienDob.getMonth();
    let dobYear = clienDob.getFullYear();
    let dateOfBirth = + new Date(dobYear, dobMonth, dobdate).getTime();
    var dateInput = + new Date(this.year, this.month - 1, this.day).getTime();
    if (dateOfBirth == dateInput) {
      this.router.navigate(['/home']);
    } else {
      this.errorFlag = true;
      this.destroyError(9000).then(() => { this.errorFlag = false; });
    }
  }
  // To get delay for user experience
  destroyError(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
}
