/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * desktophome.component.ts
 * Description: user policy details and user details will display 
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule } from '@angular/router';
import { NgNavigatorShareService } from 'ng-navigator-share';
declare var $: any;

@Component({
  selector: 'app-desktophome',
  templateUrl: './desktophome.component.html',
  styleUrls: ['./desktophome.component.css']
})
export class DesktophomeComponent implements OnInit {
  // animated veriable declearation
  public lottieConfig: Object;
  public otplottieConfig: Object;
  public emaillottieConfig: Object;
  private anim: any;
  private animotp: any;
  private animemail: any;
  inBounds = true;
  position;
  edge = {
    top: true,
    bottom: true,
    left: true,
    right: true
  };
  otpFlag : boolean = false;
  emailotpFlag : boolean = false;
  updateFlag : boolean =true;
  emailupdateFlag : boolean = true;
  nomineeFlag : boolean = true;
  nomineefeedbackFlag : boolean = false;
  nomineeOtpFlag : boolean = false;
  feedbackFlag : boolean = false;
  emailfeedbackFlag : boolean =false;
  inputAnimationFlag : boolean = false;
  surrenderFlag : boolean = true;
  elementSad : any;
  elementOkay : any;
  elementLove : any;
  userDetails: any;
  mobileNo : number;
  mobile_no : any;
  emailId : any;
  firstName : string ;
  lastName : string;
  name : string ;
  policyDetail: any;
  policyName : string;
  slides = [];
  policynum : string;
  sumAssured : any;
  dateOfBirth:any;
  private ngNavigatorShareService: NgNavigatorShareService;
  policyDummyObject = { "policyNumber": "PA1GNUE457EP570", "proposalNumber": "QM00023123", "schemeCode": "GOLD2", "policyStatus": "INFORCE", "proposalStatus": "INFORCE", "insured": { "id": "2c9283bb6abfd91a016ac0c0a4450058" }, "sumAssured": null, "product": { "name": "Aegon Life Group Term Plus Insurance Plan", "code": "138N062V01", "schemeName": "Mobikwik Mass Market", "schemeCode": "GOLD2", "planName": "Gold Option II", "planCode": "GOLD2", "master": false }, "inceptionDate": "2019-05-17", "coverages": [{ "productCode": "MBK-0001-DB", "sumAssured": 150000, "premium": 18.531, "paymentFrequency": "4", "cgstAmount": 1.67, "igstAmount": 0, "sgstAmount": 1.67 }, { "productCode": "MBK-0001-ACDMB", "sumAssured": 150000, "premium": 6.786, "paymentFrequency": "4", "cgstAmount": 0.61, "igstAmount": 0, "sgstAmount": 0.61 }], "masterPolicyNumber": "M01201903259556", "masterPolicyHolderName": "One Mobikwik Systems Private Limited", "premiumInfo": { "installPrem": 30, "stampDutyAmount": 0, "regularPremium": 25.317, "cgstAmount": 2.28, "igstAmount": 0, "sgstAmount": null }, "nominees": [], "paymentFrequency": "4", "freelookPeriod": "30", "premiumPayingTerm": "12", "premiumDueDate": "2019-06-16T18:30:00.000+0000", "policyTerm": "12", "dispatchDate": null, "docUrl": null, "expiryDate": "2020-05-15T18:30:00.000+0000", "issueDate": "2019-05-15T18:30:00.000+0000" }
  slideConfig = {
    "slidesToShow": 1, 'dots': true, 'arrows': false, "slidesToScroll": 1, 'centerMode': false, 'infinite': false, 'responsive': [
      {
        breakpoint: 694,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '30px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      },
      {
        breakpoint: 440,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '20px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      }, {
        breakpoint: 376,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '1px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      }, {
        breakpoint: 361,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '0px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      }
    ]
  };
  constructor(private ApiService: ApiService, private router: Router) {
    // animation configs
    this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/input-tick.json', true);
    this.otplottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/desktop-otp.json', false);
    this.emaillottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/desktop-otp.json', false);

  }
  
  // animation input  
  handleAnimation(anim: any) {
    this.anim = anim;
  }
  // animation otp
  handleAnimationOtp(animotp: any) {
    this.animotp = animotp;
  }
  // animation otp
  emailAnimationOtp(animemail: any) {
    this.animemail = animemail;
  }
  // trigger animation
  successAnimation() {
    this.anim.play();
  }
  // mobile modal trigger
  mobileModal(): void {
    document.body.className += ' ' + 'modal-open';
    // Get the modal
    var modal = document.getElementById("mobile-modal");
    modal.style.display = "block";
    this.otpFlag = false;
    this.feedbackFlag = false;
    this.updateFlag = true;
  }
  closeMobileModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("mobile-modal");
    modal.style.display = "none";
  }
  emailModal(): void {
    document.body.className += ' ' + 'modal-open';
    // Get the modal
    var modal = document.getElementById("email-modal");
    modal.style.display = "block";
    this.emailupdateFlag = true;
    this.emailotpFlag = false;
    this.emailfeedbackFlag = false;
  }
  closeEmailModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("email-modal");
    modal.style.display = "none";
  }
  nomineeModal(): void {
    document.body.className += ' ' + 'modal-open';
    // Get the modal
    var modal = document.getElementById("nominee-modal");
    modal.style.display = "block";
    this.nomineefeedbackFlag = false;
    this.nomineeFlag = true;
    this.nomineeOtpFlag = false;
  }
  closeNomineeModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("nominee-modal");
    modal.style.display = "none";
  }
  closeSurrenderModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("surrender-modal");
    modal.style.display = "none";
  }
  updateMobile() {
    this.otpFlag = true;
    this.updateFlag = false;
    this.ApiService.destroySuccess(3000).then(() => { this.animotp.stop(); });

  }
  updateEmail() {
    this.emailotpFlag = true;
    this.emailupdateFlag = false;
    this.ApiService.destroySuccess(3000).then(() => { this.animemail.stop(); });
  }
  updateNominee(): void {
    this.nomineeFlag = false;
    this.nomineeOtpFlag = true;

  }
  nomineeOtpVerification(): void {
    this.nomineefeedbackFlag = true;
    this.nomineeFlag = false;
    this.nomineeOtpFlag = false;
  }
  switchSad(): void {
    // feedback emojis
    this.elementSad = document.getElementById("sad");
    this.elementOkay = document.getElementById("okay");
    this.elementLove = document.getElementById("love");

    this.elementSad.classList.add("draw");
    this.elementOkay.classList.remove("draw");
    this.elementLove.classList.remove("draw");
  }
  switchOkay(): void {
    // feedback emojis
    this.elementSad = document.getElementById("sad");
    this.elementOkay = document.getElementById("okay");
    this.elementLove = document.getElementById("love");

    this.elementSad.classList.remove("draw");
    this.elementOkay.classList.add("draw");
    this.elementLove.classList.remove("draw");
  }
  switchLove(): void {
    // feedback emojis
    this.elementSad = document.getElementById("sad");
    this.elementOkay = document.getElementById("okay");
    this.elementLove = document.getElementById("love");

    this.elementSad.classList.remove("draw");
    this.elementOkay.classList.remove("draw");
    this.elementLove.classList.add("draw");
  }
  // To check 10 digits and showing check animation
  textMobile(evernt: any) {
    var target = event.srcElement;
    if (this.mobile_no) {
      var textLength = this.mobile_no.length;
    }
    if (textLength === 10) {
      this.inputAnimationFlag = true
    }
    else {
      this.inputAnimationFlag = false;
    };
  }
  //  check for only numbers
  onlyNumber(event): boolean {
    return this.ApiService.onlyNumber(event);
  }

  
  ngOnInit() {
    this.policyDetail = {};
    this.userDetails = {};
    // encrypt the policy number
    var decrypted = this.ApiService.get(localStorage.getItem('policynum'));
    this.policynum = decrypted;
    // get user policy details
    this.ApiService.apirequest('getPolicyBypolicyNumber', { "policyNumber": this.policynum, "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken  }).subscribe(data => {
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.policyDetail = data.json();
        let partyid = this.policyDetail.insured.id;
        this.sumAssured = this.policyDetail.coverages[0].sumAssured || '';
        this.getDetails(partyid);


        this.slides.push(this.policyDetail)
        this.slides.push(this.policyDummyObject)
        this.policyName = this.policyDetail.product.name;
      }
    }, err => { this.router.navigate(['/login']); })
  }
  // share the view policy doc
  sharePolicy() {
    this.ngNavigatorShareService.share({
      title: 'My Awesome app',
      text: 'hey check out my Share button',
      url: 'https://developers.google.com/web'
    }).then((response) => {

    })
      .catch((error) => {
      });
  }
  // To xxx-xxx-xx mobile number
  findandReplaceMobileNumber(str) {
    var res = str.substring(2, 8);
    res = str.replace(res, "XXX XXX")
    return res;
  }
  // clear the localStroage 
  clearstorage(): void {
    localStorage.setItem('addnominee', 'false')
  }
  // To xxx-xxx-xx email 
  findandReplaceEmail(str) {
    var res = str.substring(2, str.indexOf('@'));
    res = str.replace(res, "XXXXXXX")
    return res;
  }
  // get Deails of users
  getDetails(partyid) {
    this.ApiService.apirequest('getuserCardDetails', {"token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken , "partyid": partyid }).subscribe(data => {
      this.userDetails = data.json();
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.userDetails = data.json();
        this.firstName = this.userDetails.firstName;
        this.lastName = this.userDetails.lastName;
        this.mobileNo = this.findandReplaceMobileNumber(this.userDetails.contacts[0].contactInfo);
        this.emailId = this.findandReplaceEmail(this.userDetails.contacts[1].contactInfo);

        if (this.userDetails.lastName != null) {

          this.name = this.userDetails.firstName + ' ' + this.userDetails.lastName;
        } else {
          this.name = this.userDetails.firstName;
        }
        // encrypt the user name
        var encypted = this.ApiService.set(this.name);
        localStorage.setItem('userDetails', encypted);
        // encrypt the mobile details
        var encyptedMobile = this.ApiService.set(this.userDetails.contacts[0].contactInfo);
        localStorage.setItem('contact', encyptedMobile);

      }
    }, err => { this.router.navigate(['/login']); })
  }
  otpVerification() {
    this.animotp.play();
    this.ApiService.destroySuccess(2000).then(() => { this.otpFlag = false; this.feedbackFlag = true; });

  }
  emailOtpVerification() {
    this.animemail.play();
    this.ApiService.destroySuccess(2000).then(() => { this.emailotpFlag = false; this.emailfeedbackFlag = true; });
  }

  submitFeedback(): void {
    this.closeMobileModal();
  }
  // srrender policy
  addClass(): void {
    document.getElementById('textpara').classList.add("mystyle");
  }
  removeClass() {
    document.getElementById('textpara').classList.remove("mystyle");
  }
  // Get the modal
  // When the user clicks the button, open the modal 
  openAlert(): void {
    let modal = document.getElementById("myModal");
    modal.style.display = "block";
  }

  // When the user clicks on <span> (x), close the modal
  closeAlert(): void {
    let modal = document.getElementById("myModal");
    modal.style.display = "none";
  } 

  // resetting the card
  cardReset(): void {
    this.position = { x: 0, y: 0 }
    this.chagnedetected = true;
    this.closeAlert();
    $(".hide-move-div h5,.hide-when-slide,.freelookPeriod").css({ "opacity": "1", "transition": ".5s linear" });
  }
  // deleting the card
  deleteCard(): void {
    this.closeAlert();
    $(".swipe-card").css({ "transform": "translate(0 ,1000px)", "transition": "5s linear" });
    $(".animation-circle-ripples").addClass("animate");
    $(".freelookPeriod").css({ "opacity": "0", "transition": ".5s linear" });
    $(".hidden-text-layer").css({ "opacity": "1", "transition": ".5s linear" });
  }
  // card bottom event
  chagnedetected = false;
  checkEdge(event): void {
    this.edge = event;
    if (event.bottom == false) {
      this.chagnedetected = false;
      this.openAlert();
      $(".hide-move-div h5,.hide-when-slide").css({ "opacity": "0", "transition": ".5s linear" });
    }
    else {
      this.chagnedetected = true;
      this.position = { x: 0, y: 0 }
      $(".hide-move-div h5,.hide-when-slide").css({ "opacity": "1", "transition": ".5s linear" });
    }
  }
  closeFunctionCallback() {

  }
  openFunctionCallback() {

  }

}


