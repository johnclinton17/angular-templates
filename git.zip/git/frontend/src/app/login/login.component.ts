/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * login.component.ts
 * Description: login for mobile devlopment
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private ApiService: ApiService, private router: Router, private renderer: Renderer2) { }
  //global variable declaration
  logininfo = { mobile_number: '', email: '' }
  errorFlag: boolean = false;
  errormsg: String = "Error! Please try again."
  ngOnInit() {
    //check if already loggedin user from localstorage
    if (localStorage.getItem('accessToken') && localStorage.getItem('secretToken')) {
      this.router.navigate(['/addpolicy']);
    }
  }
  isInt(value) {
    var er = /^-?[0-9]+$/;
    return er.test(value);
  }
  userVerification(loginForm: NgForm) {
    if ((this.logininfo.mobile_number != '' || this.logininfo.email != '')) {
      if ((loginForm.valid && (this.isInt(this.logininfo.mobile_number) && this.logininfo.mobile_number.length > 9)) || (loginForm.valid && this.logininfo.email != '')) {
        this.ApiService.apirequest('userAuthenticate', this.logininfo).subscribe(data => {
          if (data) {
            let response = data.json();
            localStorage.setItem('logindata', JSON.stringify(this.logininfo));
            if (response.status) {
              this.router.navigate(['/otp']);
            }
            else {
              this.errorFlag = true;
            }
          }
          else {
            this.errorFlag = true;
          }
        }, err => {
          this.errorFlag = true;
        })
      } else {
        if (loginForm.form && loginForm.form.controls.mobile_number.invalid) { this.errormsg = 'Please enter valid mobile number'; }
        if (loginForm.form && loginForm.form.controls.email.invalid) { this.errormsg = 'Please enter valid email address'; }
        this.errorFlag = true;
      }
      this.destroySuccess(3000).then(() => { this.errorFlag = false; });
    }
  }
  destroySuccess(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  // only number will accept
  validateNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
