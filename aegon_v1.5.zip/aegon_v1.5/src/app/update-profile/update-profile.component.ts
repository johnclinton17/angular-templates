// import packages
import { Component, OnInit ,Renderer2} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  public lottieConfig: Object;
  public lottieConfigerror: Object;
  private anim: any;
  private newanim: any;
  pagetype;
  userDetails:any;
  otpFlag = false;
// firstName ;
// lastName;
mobileNo;
emailId;
addresses = {}
email_id;
mobile_no;
addressLine1;
addressLine2;
cityname;
statename;
pincode;
errorFlag = false;
errorNumberFlag= false;

constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router, private renderer: Renderer2) {
  this.lottieConfig = {
    path: 'assets/icons/animation-json/input-tick.json',
    renderer: 'canvas',
    autoplay: false,
    loop: false
  };

  this.lottieConfigerror = {
    path: 'assets/icons/animation-json/1708-success.json',
    renderer: 'canvas',
    autoplay: false,
    loop: false
  };
  
}

  handleAnimation(anim: any) {
    this.anim = anim;
  }
  handleOtpAnimation(newanim: any) {
    this.newanim = newanim;

  }

  successAnimation() {

    this.newanim.play();
  }

  textMobile(evernt : any){
    var target = event.srcElement;
    if(this.mobile_no){

  var textLength = this.mobile_no.length;
    }
  
  if(textLength === 10){
    this.anim.play();

    
  }
  else{
    this.anim.stop();
  };
  }



ngOnInit() {

 
 this.route.params.subscribe(params => {
  this.pagetype = params['pageType'];
});

 this.ApiService.apirequest('getuserCardDetails',{}).subscribe(data => {
  console.log(data.json());
  this.userDetails = data.json();
        //  this.firstName = this.userDetails.firstName;
        // this.lastName = this.userDetails.lastName;
        this.userDetails.contacts.forEach(val=>{
          if(val.contactType == "EMAIL"){

            this.emailId =val.contactInfo;
          }
          if(val.contactType == "MOBILE"){

            this.mobileNo = val.contactInfo;
          }
          
        })
        this.addresses = this.userDetails.addresses[0];
        
      })

}

  onlyNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  


otpText;
 onKey(event:any) { // without type info
     var target = event.srcElement;
     var textLength = target.value.length;
     var decryptedOtp = this.ApiService.get('123456$#@$^@1ERF', localStorage.getItem('mobileOtp'));
  console.log(target.value , decryptedOtp );
    if(textLength == 4 && target.value === decryptedOtp ){
      document.getElementById('partitioned').blur();
 var obj= {
   "email":  this.emailId,
   "mobile": this.mobile_no
 };

 this.ApiService.apirequest('getUpdateMobileNumber',obj).subscribe(data => {
  console.log(data.status);
  if(data.status == 200){
  
        this.newanim.play();
        this.destroySuccess(3000).then(() => {  this.router.navigate(['/feedback']);});
  }
  })      
    } 
    else{
      if(textLength == 4){
        
      this.errorFlag = true;
        this.destroySuccess(3000).then(() => {  this.errorFlag=false;});
      }
    }

  }


destroySuccess(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


isInt(value) {
  var er = /^-?[0-9]+$/;
  return er.test(value);
}


  dispOtp;
sendOTP(mobile_number) {
  if(this.isInt(mobile_number)){
    if(mobile_number.length){
      this.ApiService.apirequest('OTPlogin', {number:mobile_number}).subscribe(data => {
        this.dispOtp = data.json().message;
         var encyptedOtp =this.ApiService.set('123456$#@$^@1ERF', this.dispOtp);
        localStorage.setItem('mobileOtp',encyptedOtp)
        if(data.json().status){
          this.otpFlag = true;
        }
        else{
          this.errorNumberFlag = true;
          this.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
        }
      },err => {console.error(err);
       this.errorNumberFlag = true;
       this.destroySuccess(3000).then(() => {this.errorNumberFlag = false;}); 
     })
    }
  }else{
    this.errorNumberFlag = true;
    this.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
  }
  
}


updateEmail(){
  var obj = {
   "email": this.email_id,
   "mobile": this.mobileNo
 }
 this.ApiService.apirequest('getUpdateMobileNumber',obj).subscribe(data => {
  console.log(data.status);
  if(data.status == 200){
    this.router.navigate(['/feedback']);

  }
})
}



}
