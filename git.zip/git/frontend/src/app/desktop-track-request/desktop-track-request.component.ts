import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-track-request',
  templateUrl: './desktop-track-request.component.html',
  styleUrls: ['./desktop-track-request.component.css']
})
export class DesktopTrackRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
