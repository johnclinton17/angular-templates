/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * app.js
 * Description: All HTTP methods like GET, POST, PUT and DELETE APIs to retrieve data and update/insert/delete data.
 * Copyright (c) 2019 aegonlife Insurance
 */

//Including all NPM packages
var express = require('express');
//create router for API Call
var router = express.Router();
const request = require('request-promise')
// mysql drvier
var bodyParser = require('body-parser');
var mysql = require('mysql');
const CognitoExpress = require("cognito-express");
global.fetch = require('node-fetch');
const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const urlencodedParser = bodyParser.urlencoded({ extended: false })
var address = require('network-address')
var AWS = require('aws-sdk');


global.cognit = [];
const poolData = {
  UserPoolId: 'ap-south-1_QxC1rEXtv',
  ClientId: '188937jo7k9bnircev6b1c6m50'
};

const awssecret = 'AegonL1Fe';
const cognitoExpress = new CognitoExpress({
  region: "ap-south-1",
  cognitoUserPoolId: poolData.UserPoolId,
  tokenUse: "access",
  tokenExpiration: 3600000
});

// connect to mysql
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'aegon_inset'
});
//connection status check
connection.connect(function (err) { })

//function for generating OTP
function generateOTP() {
  // which stores all digits 
  var digits = '0123456789';
  let OTP = '';
  for (let i = 0; i < 4; i++) {
    OTP += digits[Math.floor(Math.random() * 10)];
  }
  return OTP;
}

//functional API for otp  
router.post('/OTPlogin', function (req, res, next) {
  var otp = generateOTP()
  res.json({ status: true, message: otp });
})

// get user Details 
router.post('/getuserCardDetails',validatetoken, function (req, res, next) {
  const options =
  {
    method: 'GET',
    uri: 'https://service-api.dt-aegonlife.com/party/' + req.body.partyid,
    headers:
    { //Token received from token endpoint "Bearer<space><access_token>"
      "Authorization": 'Bearer ' + req.body.token,
      'Content-Type': 'application/json',
      "x-api-key": "HzdFqSKB1r5X4s73Q9lwZFR06zJszB4bTtB7Le50"
    }
  }
  request(options).then(function (response) {
    res.json(JSON.parse(response));
  }).catch(function (err) {
    res.json({status:false , message: "User does not exist"});
  })
})

// get polciy by Plociy ID
router.post('/getPolicyBypolicyNumber',validatetoken, function (req, res, next) {
  const options =
  {
    method: 'GET',
    uri: 'https://service-api.dt-aegonlife.com/policy/' + req.body.policyNumber,
    headers:
    { //Token received from token endpoint "Bearer<space><access_token>"
      "Authorization": 'Bearer ' + req.body.token,
      'Content-Type': 'application/json',
      "x-api-key": "HzdFqSKB1r5X4s73Q9lwZFR06zJszB4bTtB7Le50"
    }
  }
  request(options).then(function (response) {
    res.json(JSON.parse(response));
  }).catch(function (err) {
    res.json({status:false , message: "Policy does not exist"});
  })
})

//  API to update contact details
router.post('/getUpdateMobileNumber', function (req, res, next) {
  const options = {
    method: 'PUT',
    uri: 'https://services.dt-aegonlife.com/policyv2/group/policies/GS5574445251941/endorsements/contacts',
    headers:
    { //Token received from token endpoint "Bearer<space><access_token>"
      "Authorization": 'Bearer ' + req.body.token,
      'Content-Type': 'application/json',
      "x-api-key": "HzdFqSKB1r5X4s73Q9lwZFR06zJszB4bTtB7Le50"
    }, body: req.body, json: true
  };
  request(options).then(function (response) {
    res.json(JSON.parse(response));
  }).catch(function (err) {
   res.json({status:false , message: "Somthing went wrong"});
  })
});

// access token
router.post('/getAuthenticationToken', function (req, res, next) {

  let client_id = '1ttovfembv00blq3m1ctn7lbnr';
  let client_secret = '1dfold4v1r8ath7drpsiifv4lhti3fq0uqd0kl0lhe980p43e9so';
  let buff = new Buffer(client_id + ":" + client_secret);
  let base64endcodedClientCredentials = buff.toString('base64');
  const options =
  {
    method: 'POST',
    uri: 'https://auth.dt-aegonlife.com/oauth2/token',
    headers:
    { //Base 64 encoded value of <client_id:client_secret>
      'Authorization': 'Basic ' + base64endcodedClientCredentials,
      'Content-Type': 'application/json',
      // "x-api-key" : "HzdFqSKB1r5X4s73Q9lwZFR06zJszB4bTtB7Le50"
    }, form: { grant_type: 'client_credentials' }
  }

  request(options).then(function (response) {
    let token = JSON.parse(response);
    res.json(token);
  }).catch(function (err) {
    res.json({status:false , message: "Somthing went wrong"});
  })
})

// cancel the Policy
router.post('/freelookPolicy',validatetoken, function (req, res, next) {
  const options =
  {
    method: 'POST',
    uri: 'https://service-api.dt-aegonlife.com/policy/' + req.body.policynumber + '/cancellation',
    headers:
    { //Token received from token endpoint "Bearer<space><access_token>"
      "Authorization": req.body.token,
      'Content-Type': 'application/json',
      "x-api-key": "HzdFqSKB1r5X4s73Q9lwZFR06zJszB4bTtB7Le50"
    }, body: {
      "comment": "string",
      "reason": "FINANCIAL_DIFFICULTY",
      "requestedOn": "2019-05-06T07:32:41.458Z"
    },
    json: true
  }
  request(options).then(function (response) {
    res.json(response);
  }).catch(function (err) {
    res.json({status:false , message: "Not able to process your request"});
  })
})
// access token
router.post("/userAuthenticate", function (req, res, next) {

  if ((req.body.mobile_number && req.body.mobile_number != '') || (req.body.email && req.body.email != '')) {
    let number = ''; user_name = '';
    let attributeList = [];
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    if (req.body.mobile_number && req.body.mobile_number != '') {
      user_name = number = '+91' + req.body.mobile_number;
      let dataPhoneNumber = { Name: 'phone_number', Value: number };
      let attributePhoneNumber = new AmazonCognitoIdentity.CognitoUserAttribute(dataPhoneNumber);
      attributeList.push(attributePhoneNumber);
    }
    if (req.body.mobile_number == '' && req.body.email && req.body.email != '') { user_name = req.body.email; }
    if (req.body.email && req.body.email != '') {
      let dataemail = { Name: 'email', Value: req.body.email };
      let attributeemail = new AmazonCognitoIdentity.CognitoUserAttribute(dataemail);
      attributeList.push(attributeemail);
    }
    var authenticationData = { Username: user_name, Password: awssecret };
    var userData = { Username: user_name, Pool: userPool };
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

    userPool.signUp(user_name, awssecret, attributeList, null, function (err, result) {
      if (err) {
        if (err.code == 'UsernameExistsException') {
          authenticateCallback(cognitoUser, authenticationDetails, user_name, req, function (resultdata) {
            if (resultdata.message.code && resultdata.message.code == 'UserNotConfirmedException') {
              resentotpcallback(cognitoUser, function (resenddata) {
                res.json(resenddata)
              });
            }
            else {
              res.json(resultdata);
            }
          })
        }
        else {
          res.json({ status: false, 'message': err })
        }
      }
      else {
        res.json({ status: true, 'type': 'signup', 'message': 'OTP has sent to your mobile/email address' })
      }
    });
  }
  else {
    res.json({ status: false, 'message': 'Error! Please try Again' })
  }
});
// access token
router.post("/otpVerification", function (req, res, next) {

  if (((req.body.mobile_number && req.body.mobile_number != '') || (req.body.email && req.body.email != '')) && req.body.otpText) {
    let user_name = '';
    if (req.body.mobile_number && req.body.mobile_number != '') { user_name = number = '+91' + req.body.mobile_number; }
    if (req.body.mobile_number == '' && req.body.email && req.body.email != '') { user_name = req.body.email; }
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    var authenticationData = { Username: user_name, Password: awssecret };
    var userData = { Username: user_name, Pool: userPool };
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

    if (global.cognit[user_name]) {
      if (req.body.otp_type == 'resend') {
        authenticateCallback(cognitoUser, authenticationDetails, user_name, req, function (resultdata) {
          if (resultdata)
            res.json(resultdata);
        });
      }
      else {
        var cognitoUser1 = global.cognit[user_name];
        cognitoUser1.sendMFACode(String(req.body.otpText), {
          onSuccess: function (result) {
            var accessToken = result.getAccessToken().getJwtToken();
            var secretToken = result.idToken.jwtToken;
            res.json({ status: true, 'message': 'success', accessToken: accessToken, secretToken: secretToken, ss: req.session[user_name], mm: global.cognit[user_name] })
          },
          onFailure: function (err) {
            res.json({ status: false, 'message': err })
          },
        }, 'SMS_MFA');
      }
    }
    else {
      if (req.body.otp_type == 'resend') {
        cognitoUser.resendConfirmationCode(function (err, result) {
          if (err) {
            res.json({ status: false, 'message': err });
          }
          else {
            res.json({ status: true, 'message': 'success' });
          }
        });
      }
      else {
        cognitoUser.confirmRegistration(String(req.body.otpText), true, function (err, result) {
          if (err) {
            res.json({ status: false, 'message': err })
          }
          else {
            authenticateCallback(cognitoUser, authenticationDetails, user_name, req, function (resultdata) {
              smsMfaSettings = {
                PreferredMfa: true,
                Enabled: true
              };
              cognitoUser.setUserMfaPreference(smsMfaSettings, null, function (err, result) {
                res.json(resultdata);
              });
            })
          }
        });
      }
    }
  }
  else {

    res.json({ status: false, 'message': 'Error! Please try Again' })
  }
});

// insert Feedback
router.post("/insertfeedback", urlencodedParser, function (req, res) {
  const ip_address = address();
  var insert_feedback = "insert into feedback(party_id,ratings,message,feedback_date,name,email,mobile_no,screen_name,policy_number,device_type,os_type,ip_address,browser,os_version,browser_version)values('" + req.body.party_id + "','" + req.body.ratings + "','" + req.body.message + "',now(),'" + req.body.name + "','" + req.body.email + "','" + req.body.mobile_no + "','" + req.body.screen_name + "','" + req.body.policy_number + "','" + req.body.device_type + "','" + req.body.os_type + "','" + ip_address + "','" + req.body.browser + "','" + req.body.os_version + "','" + req.body.browser_version + "')";
  connection.query(insert_feedback, function (err, rows, fileds) {
    if (err) {
      res.send(err.message);
    }
    else {
      res.send({ "message": "inserted" });
    }
  })

})

// insert user details
router.post("/insertUserDetails", urlencodedParser, function (req, res) {
  var insert_details = "insert into party_info(policynumber,mobile_no,email_id,created_date)values('" + req.body.policyNumber + "','" + req.body.mobile + "','" + req.body.email + "',now())";
  connection.query(insert_details, function (err, rows, fileds) {
    if (err) {
      res.send(err.message);
    }
    else {
      res.send({ "message": "inserted" });
    }
  })
})

function resentotpcallback(cognitoUser, callback) {
  cognitoUser.resendConfirmationCode(function (err, result) {
    if (err) {
      callback({ status: false, 'message': err })
    }
    else {
      callback({ status: true, 'type': 'signup', 'message': 'OTP has sent to your mobile number' })
    }
  });
}
function authenticateCallback(cognitoUser, authenticationDetails, user_name, req, callback) {
  cognitoUser.authenticateUser(authenticationDetails, {
    onSuccess: function (result) {
      var accessToken = result.getAccessToken().getJwtToken();
      var secretToken = result.idToken.jwtToken;
      callback({ status: true, 'message': 'success', accessToken: accessToken, secretToken: secretToken })
    },
    onFailure: function (err) {
      callback({ status: false, 'message': err })
    },
    mfaRequired: function (codeDeliveryDetails) {
      if (codeDeliveryDetails == 'SMS_MFA') {
        global.cognit[user_name] = cognitoUser;
        callback({ status: true, 'message': 'success' })
      }
      else {
        callback({ status: false, 'message': '' })
      }
    }
  });
}

//callback function to check if the users is valid.
function validatetoken(req, res, next) {
  if (req.body.accessToken && req.body.accessToken != '' && req.body.token && req.body.token != '') {
    cognitoExpress.validate(req.body.accessToken, function (err, response) {
      if (err) {
        return res.json({ status: false, status_code: 'invalid_access_token', 'message': 'Invalid access token. Please logout and login again.' });
      }
      else {
        return next();
      }
    });
  }
  else {
    return res.json({ status: false, status_code: 'no_access_token', 'message': 'No access token. Please logout and login again.' });
  }
}
//export the router method to call in server.js
module.exports = router;
