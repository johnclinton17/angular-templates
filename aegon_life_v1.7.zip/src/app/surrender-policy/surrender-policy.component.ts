/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * surrender.component.ts
 * Description: surrender Policy
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit, AfterViewInit, HostListener ,ElementRef,ViewChild} from '@angular/core';
import { Router, RouterModule, ActivatedRoute, NavigationStart } from '@angular/router';
import Swal from 'sweetalert2/dist/sweetalert2.all.js'

declare var $ : any ;
@Component({
  selector: 'app-surrender-policy',
  templateUrl: './surrender-policy.component.html',
  styleUrls: ['./surrender-policy.component.css']
})
export class SurrenderPolicyComponent implements OnInit{
  inBounds = true;
  edge = {
    top: true,
    bottom: true,
    left: true,
    right: true
  };

  
  bottomflag = true; 
  @ViewChild("block", {read: ElementRef}) block: ElementRef;
  @HostListener('touchmove', ['$event'])
  handleWheelEvent(event) {
    event.preventDefault();
    //console.log('move not working');
  }

  constructor(route: ActivatedRoute,private router: Router) {
  }

  ngOnInit() {

    
  }




  success(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  addClass(){
    document.getElementById('textpara').classList.add("mystyle");
    // document.getElementById('remove-line').classList.add("move-top");
  }

  removeClass(){
    document.getElementById('textpara').classList.remove("mystyle"); 
    // document.getElementById('remove-line').classList.remove("move-top");
  }



chagnedetected = false;
  checkEdge(event) {
    this.edge = event;
    if(event.bottom==false){
      Swal.fire({
        title: 'Are you sure you want to Surrender this policy',
        text: '',
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.value) {

            $(".swipe-card").css({ "transform": "translate(0 ,1000px)", "transition": "5s linear"});
      $(".animation-circle-ripples").addClass("animate");
      $(".hide-move-div h5").css({ "opacity": "0" , "transition": ".5s linear"});
      $(".hide-when-slide").css({ "opacity": "0" , "transition": ".5s linear"});
      $(".hidden-text-layer").css({ "opacity": "1" , "transition": ".5s linear"});
      //  this.success(8500).then(() => {this.router.navigate(['/feedback']);  });
          this.chagnedetected = false;

        } else if (result.dismiss === Swal.DismissReason.cancel) {
                 // this.chagnedetected = true;
          console.log('asfjkkkjkk');
        }
      })
              this.chagnedetected = false;
        
    }
    else{
      this.chagnedetected = true;
    }
    // this.bottomflag = event.bottom;
    // console.log('edge:', event.bottom);
    //console.log('started:', event.bottom);
  }
}
