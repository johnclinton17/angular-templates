import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-login',
  templateUrl: './desktop-login.component.html',
  styleUrls: ['./desktop-login.component.css']
})
export class DesktopLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
