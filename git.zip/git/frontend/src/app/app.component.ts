/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * app.component.ts
 * Description: router animation
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, Renderer2 } from '@angular/core';
import { ApiService } from './api/api.service'
import { Router, RouterModule, ActivatedRoute, Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart } from '@angular/router';
import { trigger, transition, group, query, style, animate } from '@angular/animations';
import { ResponsiveService } from './responsive.service';
import { pairwise } from 'rxjs/operators';
declare var window: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('routeAnimation', [
      transition('login => otp,otp => addpolicy, addpolicy => home, home => updateaccount,home => profile ,updateaccount => profile , profile => feedback, home => surrender, home => nominee, home => support, home => track', [
        style({ height: '!' }),
        query(':enter', style({ transform: 'translateX(100%)' })),
        query(':enter, :leave', style({ position: 'absolute', top: 0, left: 0, right: 0 })),
        // animate the leave page away
        group([
          query(':leave', [
            animate('.300s ease', style({ transform: 'translateX(-100%)' })),
          ]),
          // and now reveal the enter
          query(':enter', animate('.300s ease', style({ transform: 'translateX(0)' }))),
        ]),
      ]),
      transition('otp => login,addpolicy => login, profile=> updateaccount, profile=> home, updateaccount => home, feedback => profile,surrender => home,nominee => home, support => home, track => home', [
        style({ height: '!' }),
        query(':enter', style({ transform: 'translateX(-100%)' })),
        query(':enter, :leave', style({ position: 'absolute', top: 0, left: 0, right: 0 })),
        // animate the leave page away
        group([
          query(':leave', [
            animate('.300s ease', style({ transform: 'translateX(100%)' })),
          ]),
          // and now reveal the enter
          query(':enter', animate('.300s ease', style({ transform: 'translateX(0)' }))),
        ]),
      ]),
    ])
  ]
})
export class AppComponent {
  previousUrl : string = '';
  loader: boolean;
  getDepth(outlet) {
    return outlet.activatedRouteData['depth'];
  }
  constructor(private renderer: Renderer2, private router: Router, private responsiveService: ResponsiveService) {
    this.router.events
      .subscribe((event) => {
        // loader on each page navigation
        if (event instanceof NavigationStart) {
          switch (true) {
            case event instanceof NavigationStart: {
              this.loader = true;
              this.destroySuccess(1000).then(() => { this.loader = false; });
              break;
            }
            case event instanceof NavigationEnd:
            case event instanceof NavigationCancel:
            case event instanceof NavigationError: {
              this.loader = false;
              break;
            }
            default: {
              break;
            }
          }
          // router animation
          if (this.previousUrl) {
            localStorage.setItem('previousUrl', this.previousUrl);
            this.renderer.removeClass(document.body, this.previousUrl);
          }
          let currentUrlSlug = '';
          currentUrlSlug = event.url.slice(1)
          if (currentUrlSlug) {
            var str = currentUrlSlug.replace('/', '')
            if (this.previousUrl) {
              var prestr = this.previousUrl.replace('/', '')
              this.renderer.removeClass(document.body, prestr);
            }
            this.renderer.addClass(document.body, str);
          }
          this.previousUrl = currentUrlSlug;
        }
      });
  }
  ngOnInit() {
   
    this.responsiveService.getMobileStatus().subscribe(isMobile => {
      if (!isMobile) {
        var body = document.body;
        body.classList.add("desktop");
      }
    });
    this.onResize();
  }
  //  check the resize event of window
  onResize(): void  {
    this.responsiveService.checkWidth();
  }
  destroySuccess(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

