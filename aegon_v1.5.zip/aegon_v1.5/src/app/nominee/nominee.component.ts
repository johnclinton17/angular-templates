import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-nominee',
  templateUrl: './nominee.component.html',
  styleUrls: ['./nominee.component.css']
})
export class NomineeComponent implements OnInit {

    constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router) { }
nomineeFlag ;
policyDeatil : any;
policyName;
clientName;
  ngOnInit() {
  	this.nomineeFlag = 'false';
  	if(localStorage.getItem('addnominee')){
this.nomineeFlag = localStorage.getItem('addnominee');
  	}

  this.policyDeatil={};
this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": "GS5574445251941"}).subscribe(data => {
        console.log(data.json());
        this.policyDeatil = data.json();
        this.policyName = this.policyDeatil.product.name;
    })

  var decrypted = this.ApiService.get('123456$#@$^@1ERF', localStorage.getItem('userDetails'));
  console.log(decrypted);
this.clientName = decrypted;

  }

  getPercentage(percentage){
    return percentage+'%';
  }
  getColor(index) {
    switch (index) {
      case 0:
        return '#49AF57';
      case 1:
        return '#9B66CE';
      case 2:
        return '#FF4B13';
      case 3:
        return '#37B8FF';
      case 4:
        return '#013297';
      case 5:
        return '#707070';
    }
  }

}
