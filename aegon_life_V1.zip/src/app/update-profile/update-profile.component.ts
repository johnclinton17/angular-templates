import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  public lottieConfig: Object;
  private anim: any;
  pagetype;
  userDetails:any;
firstName ;
lastName;
mobileNo;
emailId;
addresses = {}
email_id;
mobile_no;
addressLine1;
addressLine2;
cityname;
statename;
pincode;

  constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router) {
    this.lottieConfig = {
      path: 'assets/icons/animation-json/input-tick.json',
      renderer: 'canvas',
      autoplay: false,
      loop: false
    };

   }

  handleAnimation(anim: any) {
    this.anim = anim;
  }

textMobile(evernt : any){
	var target = event.srcElement;
     var textLength = this.mobile_no.length;
if(textLength === 10){
this.anim.play();
}
else{
	this.anim.stop();
}
}
 


  ngOnInit() {

  	this.route.params.subscribe(params => {
      this.pagetype = params['pageType'];
    });

 this.ApiService.apirequest('getuserCardDetails',{}).subscribe(data => {
        console.log(data.json());
        this.userDetails = data.json();
         this.firstName = this.userDetails.firstName;
        this.lastName = this.userDetails.lastName;
        this.userDetails.contacts.forEach(val=>{
        if(val.contactType == "EMAIL"){

        this.emailId =val.contactInfo;
        }
      if(val.contactType == "MOBILE"){

        this.mobileNo = val.contactInfo;
        }
          
        })
        this.addresses = this.userDetails.addresses[0];
        
      })

  }


  updateMobile(){
    var obj= {
 "email":  this.emailId,
 "mobile": this.mobile_no
};

    this.ApiService.apirequest('getUpdateMobileNumber',obj).subscribe(data => {
        console.log(data.status);
        if(data.status == 200){
this.router.navigate(['/feedback']);

        }
      })
  }

  updateEmail(){
var obj = {
 "email": this.email_id,
 "mobile": this.mobileNo
}
console.log(obj);
    this.ApiService.apirequest('getUpdateMobileNumber',obj).subscribe(data => {
        console.log(data.status);
        if(data.status == 200){
this.router.navigate(['/feedback']);

        }
      })
  }

  updateCommunicationAddress(){


var obj = {
"addresses": [
    {
      "addressType": "RESIDENCE",
      "addressLine1": this.addressLine1,
      "addressLine2": this.addressLine2,
      "addressLine3": null,
      "addressLine4": null,
      "country": "India",
      "state": this.statename,
      "city": this.cityname,
      "pincode": this.pincode
    }
  ],
  "email": this.emailId,
 "mobile": this.mobileNo
}
console.log(obj);
    this.ApiService.apirequest('getUpdateMobileNumber',obj).subscribe(data => {
        console.log(data.status);
        if(data.status == 200){
this.router.navigate(['/feedback']);

        }
      })
  }

}
