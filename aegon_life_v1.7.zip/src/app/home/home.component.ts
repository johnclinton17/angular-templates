/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * home.component.ts
 * Description: Home screen with user details and policy details
 * Copyright (c) 2019 aegonlife Insurance
 */


import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private ApiService: ApiService, private router: Router) { }

userDetails :any;
mobileNo;
emailId;
firstName ;
lastName;
name;
prolicyDetail;
policyName;
slides=[];
  ngOnInit() {
this.getDetails();
this.userDetails={};
this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": "GS5574445251941"}).subscribe(data => {
  console.log(data);
        this.prolicyDetail = data.json();
        this.slides.push(this.prolicyDetail)
        this.policyName = this.prolicyDetail.product.name;
    })
  }

sharePolicy(){
  let newVariable: any;

newVariable = window.navigator;

if (newVariable && newVariable.share) {
  newVariable.share({
    title: 'title',
    text: 'description',
    url: 'https://soch.in//',
  })
    .then(() => console.log('Successful share'))
    .catch((error) => console.log('Error sharing', error));
} else {
  alert('share not supported');
}
}


  // To xxx-xxx-xx mobile number

findandReplaceMobileNumber(str){
  var res = str.substring(2, 8);
  res=str.replace(res, "XXX XXX")
  return res;
}
// clear the localStroage 
  clearstorage(){   
  localStorage.setItem('addnominee', 'false')
  }

 // To xxx-xxx-xx email 
  findandReplaceEmail(str){
  var res = str.substring(2, str.indexOf('@'));
  res=str.replace(res, "XXXXXXX")
  return res;
  }

// get Deails of users
getDetails() {
      this.ApiService.apirequest('getuserCardDetails',{}).subscribe(data => {
     
        
       if(data){  	
        this.userDetails = data.json();
        this.firstName = this.userDetails.firstName;
        this.lastName = this.userDetails.lastName;
        this.mobileNo = this.findandReplaceMobileNumber(this.userDetails.contacts[0].contactInfo);
        this.emailId =this.findandReplaceEmail(this.userDetails.contacts[1].contactInfo);

        if(this.userDetails.lastName != null){

         this.name = this.userDetails.firstName + ' ' + this.userDetails.lastName;
        }else{
           this.name = this.userDetails.firstName;
        }
        var encypted =this.ApiService.set('123456$#@$^@1ERF', this.name);
        localStorage.setItem('userDetails', encypted);
        

       }
    },err => {console.error(err);})
    }


}
