/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * desktoplogin.component.ts
 * Description: desktop login for users
 * Copyright (c) 2019 aegonlife Insurance
 */


import { Component, OnInit, Renderer2 } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { LottieAnimationViewModule } from 'ng-lottie';

@Component({
  selector: 'app-desktop-login',
  templateUrl: './desktop-login.component.html',
  styleUrls: ['./desktop-login.component.css']
})
export class DesktopLoginComponent implements OnInit {
  // animated veriable declearation
  public lottieConfig: Object;
  private anim: any;
  otpFlag :boolean;
  addPolicyFlag :boolean;
  mobile_number;email;errorNumberFlag :boolean;

  constructor(private ApiService: ApiService, private router: Router, private renderer: Renderer2) {
    // animation configs
    this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/desktop-otp.json', true);
   }

  handleAnimation(anim: any) {
    this.anim = anim;
  }

  successAnimation() {
    this.anim.play();
  }


  ngOnInit() {
  }

  userOTPlogin() {
    this.otpFlag = true;
    this.ApiService.destroySuccess(3000).then(() => { this.addPolicyFlag = true; this.anim.stop(); });

  }

  userPolicy(){
    this.ApiService.destroySuccess(3000).then(() => {this.router.navigate(['/home']);  });// 
  }


  otpmodal(){
    // Get the modal
  var modal = document.getElementById("otp-modal");
  modal.style.display = "block";
  }

  closeOtpModal(){
    var modal = document.getElementById("otp-modal");
    modal.style.display = "none";
  }



// only number will accepet
onlyNumber(event): boolean {
  return this.ApiService.onlyNumber(event);
  }
}
