import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-desktop-header',
  templateUrl: './desktop-header.component.html',
  styleUrls: ['./desktop-header.component.css']
})
export class DesktopHeaderComponent implements OnInit {

  constructor(private ApiService: ApiService) { }
  clientName :string;
  mobileNumber :string;
  surrenderModal() {
    document.body.className += ' ' + 'modal-open';
    // Get the modal
    var modal = document.getElementById("surrender-modal");
    modal.style.display = "block";
  }
  ngOnInit() {
    var decrypted = this.ApiService.get(localStorage.getItem('userDetails'));
    this.clientName = decrypted;
    var mobileNoDecrypted = this.ApiService.get(localStorage.getItem('contact'));
    this.mobileNumber = mobileNoDecrypted;
  }
  myFunction() {
    var x = document.getElementById("myDIV");
    if (x.innerText === "English") {
      x.innerText = "हिंदी";
    } else {
      x.innerText = "English";
    }
  }
  logOut() {
  }
}
