import { Component, OnInit,Renderer2 } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  constructor(private ApiService: ApiService, private router: Router, private renderer: Renderer2){ }

  ngOnInit() {
  }


  errorNumberFlag=false;

dispOtp;

isInt(value) {
  var er = /^-?[0-9]+$/;
  return er.test(value);
}

userOTPlogin(mobile_number) {
  if(this.isInt(mobile_number)){
    if(mobile_number.length == 10){
      this.ApiService.apirequest('getAuthenticationToken', {}).subscribe(token => {
        localStorage.setItem('token',token.json().access_token)
      })
      this.ApiService.apirequest('OTPlogin', {number:mobile_number}).subscribe(data => {
        console.log(data.json());
        localStorage.setItem('otpcode',data.json().message)
        localStorage.setItem('token',data.json().token)
        this.dispOtp = data.json().message;
        if(data.json().status){
        	 this.router.navigate(['/otp']);
        }
        else{
          this.errorNumberFlag = true;
          this.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
        }
      },err => {console.error(err);
       this.errorNumberFlag = true;
       this.destroySuccess(3000).then(() => {this.errorNumberFlag = false;}); 
     })
    }
  }else{
    this.errorNumberFlag = true;
    this.destroySuccess(3000).then(() => {this.errorNumberFlag = false;});
  }
  
}

destroySuccess(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


// only number will accepet
onlyNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }


}
