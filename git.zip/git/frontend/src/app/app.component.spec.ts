import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { MzNavbarModule, MzSidenavModule, MzButtonModule, MzDropdownModule, MzCardModule, MzBadgeModule, MzCheckboxModule, MzTextareaModule, MzSelectModule, MzDatepickerModule, MzCollapsibleModule } from 'ngx-materialize';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './header/header.component';
import { OtpComponent } from './otp/otp.component';
import { ApiService } from './api/api.service';
import { ResponsiveService } from './responsive.service';
import { LottieAnimationViewModule } from 'ng-lottie';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { HomeComponent } from './home/home.component';
import { MzModalModule } from 'ngx-materialize';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SurrenderPolicyComponent } from './surrender-policy/surrender-policy.component';
import { NomineeComponent } from './nominee/nominee.component';
import { AngularDraggableModule } from 'angular2-draggable';
import { AuthGuard } from './auth.guard';
import { SupportComponent } from './support/support.component';
import { TrackRequestComponent } from './track-request/track-request.component';
import { LoginComponent } from './login/login.component';
import { AddPolicyComponent } from './add-policy/add-policy.component';
import { DesktopLoginComponent } from './desktop-login/desktop-login.component';
import { DesktophomeComponent } from './desktophome/desktophome.component';
import { DesktopHeaderComponent } from './desktop-header/desktop-header.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { DesktopTrackRequestComponent } from './desktop-track-request/desktop-track-request.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
const mobileRoutes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent, data: { depth: 'login' } },
  { path: 'otp', component: OtpComponent, data: { depth: 'otp' } },
  { path: 'addpolicy', component: AddPolicyComponent, canActivate: [AuthGuard], data: { depth: 'addploicy' } },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard], data: { depth: 'home' } },
  { path: 'updateaccountinfo', component: UpdateAccountComponent, canActivate: [AuthGuard], data: { depth: 'updateaccount' } },
  { path: 'updateprofile/:pageType', component: UpdateProfileComponent, canActivate: [AuthGuard], data: { depth: 'profile' } },
  { path: 'feedback', component: FeedbackComponent, canActivate: [AuthGuard], data: { depth: 'feedback' } },
  { path: 'nominee', component: NomineeComponent, canActivate: [AuthGuard], data: { depth: 'nominee' } },
  { path: 'surrenderpolicy', component: SurrenderPolicyComponent, canActivate: [AuthGuard], data: { depth: 'surrender' } },
  { path: 'support', component: SupportComponent, canActivate: [AuthGuard], data: { depth: 'support' } },
  { path: 'trackrequest', component: TrackRequestComponent, canActivate: [AuthGuard], data: { depth: 'track' } },
]

const desktopRoutes = [
  { path: '', component: DesktopLoginComponent },
  { path: 'login', component: DesktopLoginComponent, data: { depth: 'desklogin' } },
  { path: 'home', component: DesktophomeComponent, data: { depth: 'deskhome' } },
]
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
    AppComponent,
    HeaderComponent,
    OtpComponent,
    HomeComponent,
    UpdateAccountComponent,
    UpdateProfileComponent,
    FeedbackComponent,
    SurrenderPolicyComponent,
    NomineeComponent,
    SupportComponent,
    TrackRequestComponent,
    LoginComponent,
    AddPolicyComponent,
    DesktopLoginComponent,
    DesktophomeComponent,
    DesktopHeaderComponent,
    DesktopTrackRequestComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(mobileRoutes, { scrollPositionRestoration: 'top' }),
    DeviceDetectorModule.forRoot(),
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MzNavbarModule,
    MzSidenavModule,
    MzButtonModule,
    MzTextareaModule,
    MzDropdownModule,
    MzCardModule,
    MzCollapsibleModule,
    MzCheckboxModule,
    MzDatepickerModule,
    MzSelectModule,
    MzModalModule,
    MzBadgeModule,
    SlickCarouselModule,
    AngularDraggableModule,
    LottieAnimationViewModule.forRoot(),
    ServiceWorkerModule.register('../ngsw-worker.js', { enabled: environment.production })
  ],
       providers: [ResponsiveService]
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'Apple '`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('Apple ');
  });

  it('should render title in a h1 tag', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to Apple !');
  });
});
