/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * home.component.ts
 * Description: Home screen with user details and policy details
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule } from '@angular/router';
import { NgNavigatorShareService } from 'ng-navigator-share';
import { DeviceDetectorService } from 'ngx-device-detector';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private ngNavigatorShareService: NgNavigatorShareService;
  userDetails: any;
  mobileNo : number;
  emailId :any ;
  firstName : string;
  lastName : string;
  name : string;
  policyDetail : any;
  policyName : string;
  slides = [];
  deviceInfo : any;
  policynum : string;
  sumAssured : string;
  policyDummyObject = { "policyNumber": "PA1GNUE457EP570", "proposalNumber": "QM00023123", "schemeCode": "GOLD2", "policyStatus": "INFORCE", "proposalStatus": "INFORCE", "insured": { "id": "2c9283bb6abfd91a016ac0c0a4450058" }, "sumAssured": null, "product": { "name": "Aegon Life Group Term Plus Insurance Plan", "code": "138N062V01", "schemeName": "Mobikwik Mass Market", "schemeCode": "GOLD2", "planName": "Gold Option II", "planCode": "GOLD2", "master": false }, "inceptionDate": "2019-05-17", "coverages": [{ "productCode": "MBK-0001-DB", "sumAssured": 150000, "premium": 18.531, "paymentFrequency": "4", "cgstAmount": 1.67, "igstAmount": 0, "sgstAmount": 1.67 }, { "productCode": "MBK-0001-ACDMB", "sumAssured": 150000, "premium": 6.786, "paymentFrequency": "4", "cgstAmount": 0.61, "igstAmount": 0, "sgstAmount": 0.61 }], "masterPolicyNumber": "M01201903259556", "masterPolicyHolderName": "One Mobikwik Systems Private Limited", "premiumInfo": { "installPrem": 30, "stampDutyAmount": 0, "regularPremium": 25.317, "cgstAmount": 2.28, "igstAmount": 0, "sgstAmount": null }, "nominees": [], "paymentFrequency": "4", "freelookPeriod": "30", "premiumPayingTerm": "12", "premiumDueDate": "2019-06-16T18:30:00.000+0000", "policyTerm": "12", "dispatchDate": null, "docUrl": null, "expiryDate": "2020-05-15T18:30:00.000+0000", "issueDate": "2019-05-15T18:30:00.000+0000" }
  slideConfig = {
    "slidesToShow": 1, 'dots': true, "slidesToScroll": 1, 'centerMode': true, 'infinite': false, 'responsive': [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '20px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      },
      {
        breakpoint: 440,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '30px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      }, {
        breakpoint: 361,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '0px',
          slidesToShow: 1,
          dots: true,
          focusOnSelect: false
        }
      }
    ]
  };

  constructor(private ApiService: ApiService, private router: Router, private deviceService: DeviceDetectorService) { this.epicFunction(); }
  // device detector
  epicFunction() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    const isMobile = this.deviceService.isMobile();
    const isTablet = this.deviceService.isTablet();
    const isDesktopDevice = this.deviceService.isDesktop();
  }
  ngOnInit() {

    this.userDetails = {};
    // encrypt the policy number
    var decrypted = this.ApiService.get(localStorage.getItem('policynum'));
    this.policynum = decrypted;
    // get user policy details
    this.ApiService.apirequest('getPolicyBypolicyNumber', { "policyNumber": this.policynum, "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken  }).subscribe(data => {
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.policyDetail = data.json();
        if(this.policyDetail.insured){

        let partyid = this.policyDetail.insured.id;
        this.sumAssured = this.policyDetail.coverages[0].sumAssured || '';
        this.getDetails(partyid);
        this.slides.push(this.policyDetail)
        this.slides.push(this.policyDummyObject)
        this.policyName = this.policyDetail.product.name;
        }
      }
    }, err => { console.error(err); })
  }
  // share the view policy doc
  sharePolicy() {
    this.ngNavigatorShareService.share({
      title: 'My Awesome app',
      text: 'hey check out my Share button',
      url: this.policyDetail.docUrl
    }).then((response) => {
    })
      .catch((error) => {
      });
  }
  // To xxx-xxx-xx mobile number
  findandReplaceMobileNumber(str) {
    var res = str.substring(2, 8);
    res = str.replace(res, "XXX XXX")
    return res;
  }
  // clear the localStroage 
  clearstorage() {
    localStorage.setItem('addnominee', 'false')
  }
  // To xxx-xxx-xx email 
  findandReplaceEmail(str) {
    var res = str.substring(2, str.indexOf('@'));
    res = str.replace(res, "XXXXXXX")
    return res;
  }
  // get Deails of users
  getDetails(partyid) {
    this.ApiService.apirequest('getuserCardDetails', { "token": this.ApiService.getaccessToken().token, "accessToken" :  this.ApiService.getaccessToken().accessToken ,"partyid": partyid }).subscribe(data => {
      this.userDetails = data.json();
      if (data.json().statusCode) {
        this.router.navigate(['/login']);
      } else {
        this.userDetails = data.json();
        this.firstName = this.userDetails.firstName;
        this.lastName = this.userDetails.lastName;
        this.mobileNo = this.findandReplaceMobileNumber(this.userDetails.contacts[0].contactInfo);
        this.emailId = this.findandReplaceEmail(this.userDetails.contacts[1].contactInfo);
        if (this.userDetails.lastName != null) {
          this.name = this.userDetails.firstName + ' ' + this.userDetails.lastName;
        } else {
          this.name = this.userDetails.firstName;
        }
        // name encrypted
        var encyptedName = this.ApiService.set( this.name);
        localStorage.setItem('userDetails', encyptedName);
        //mobile no. encrypted
        var encyptedMobile = this.ApiService.set( this.userDetails.contacts[0].contactInfo);
        localStorage.setItem('contact', encyptedMobile);
        var encypted_id = this.ApiService.set( this.userDetails.id);
        localStorage.setItem('partyid', encypted_id);
      }
    }, err => { this.router.navigate(['/login']); })
  }
}
