/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * service.ts
 * Description: All HTTP methods like GET, POST, PUT and DELETE APIs to retrieve data and update/insert/delete data.
 * Copyright (c) 2019 aegonlife Insurance
 */

//import all dependency file for initiate service
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable, Subject, ReplaySubject, from, of, range } from 'rxjs';
import { map, filter, switchMap, catchError, retry ,takeUntil} from 'rxjs/operators';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})

export class ApiService {
private _unsubscribeAll: Subject<any>;
  constructor(private _http: Http) {  // Set the private defaults
        this._unsubscribeAll = new Subject(); }

  // url to connect with the node server
  apiUrl = "http://192.168.1.13:5000" // node server
  //post api servcies
  httpOptions = {
    withCredentials: true
  };
  apirequest(url, params) {
    // set Expiry time for JWT token
    var expirationMS = 350 * 60 * 1000;
    var record = { value: JSON.stringify('expiry'), timestamp: new Date().getTime() + expirationMS }
    localStorage.setItem('expirecheck', JSON.stringify(record));
    return this._http.post(this.apiUrl + "/" + url, params).pipe(map(res => res),takeUntil(this._unsubscribeAll) ,catchError(err => {
      return of(null);
    })
    );
  }
  // get api services
  getRequest(url): Observable<any> {
    return this._http.get(url).pipe(map(res => res), takeUntil(this._unsubscribeAll),catchError(err => {
      return of(null);
    }));
  }
  // encryp and decrypt service methods
  set(value) {
    var key = CryptoJS.enc.Utf8.parse('123456$#@$^@1ERF');
    var iv = CryptoJS.enc.Utf8.parse('123456$#@$^@1ERF');
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(value.toString()), key,
      {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      });

    return encrypted.toString();
  }
  //The get method is use for decrypt the value.
  get(value) {
    var key = CryptoJS.enc.Utf8.parse('123456$#@$^@1ERF');
    var iv = CryptoJS.enc.Utf8.parse('123456$#@$^@1ERF');
    var decrypted = CryptoJS.AES.decrypt(value, key, {
      keySize: 128 / 8,
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });

    return decrypted.toString(CryptoJS.enc.Utf8);
  }
  // promise to get some delay 
  destroySuccess(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  //  animation config
  animationConfig(path, autoplay) {
    var lottieConfig = {
      path: path,
      renderer: 'canvas',
      autoplay: autoplay,
      loop: false
    };
    return lottieConfig;
  }
  // onlynumber on keybaord press 
  onlyNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

// get token to access api's
getaccessToken(){

let tokenObj = {
"token": localStorage.getItem('token'),
"accessToken": localStorage.getItem('accessToken')
}
return tokenObj;
}

 ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

}
