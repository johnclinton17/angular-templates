/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * support.component.ts
 * Description: support will povide user assistance
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit {

  constructor(private ApiService: ApiService) { }
  clientName: string;
  ngOnInit() {
    var decryptedName = this.ApiService.get( localStorage.getItem('userDetails'));
    this.clientName = decryptedName;
  }

}
