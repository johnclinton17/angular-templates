/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * otp.component.ts
 * Description: Otp authentication of user
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit, ViewChild, OnDestroy, Renderer2 } from '@angular/core';
import { Injectable } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements OnInit {

  screenFlag: boolean = false;
  errorFlag = false;
  errorNumberFlag = false;
  otpText: any = [];
  // animated veriable declearation
  public lottieConfig: Object;
  public lottieConfigerror: Object;
  private anim: any;
  private erroranim: any;
  optstart: boolean = false;
  loader: boolean = false;
  constructor(private ApiService: ApiService, private router: Router, private renderer: Renderer2) {
     // animation configs
    this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/1708-success.json', false);
    this.lottieConfigerror = this.ApiService.animationConfig('assets/icons/animation-json/4903-failed.json', false);
    this.renderer.addClass(document.body, 'otp');
  }
  ngOnDestroy() {
    this.renderer.removeClass(document.body, 'otp');
  }
  handleAnimation(anim: any) {
    this.anim = anim;
  }
  handleErrorAnimation(erroranim: any) {
    this.erroranim = erroranim;
  }
  successAnimation() {
    this.anim.play();
  }
  ngOnInit() {

  }
  destroySuccess(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  validateotp(event) {
    let element = event.srcElement.nextElementSibling;
    let preelement = event.srcElement.previousElementSibling;
    if (event.code == 'Backspace') {
      element = event.srcElement.previousElementSibling;
    }
    if (event.code != 'Backspace' && event.target.value == '' || event.code != 'Backspace' && event.target.value == ' ') {
      return
    }
    var otp = this.otpText.join('');
    if (otp.length == 6 && !this.optstart) {
      this.optstart = true;
      var logininfo = JSON.parse(localStorage.getItem('logindata'));
      logininfo.otpText = otp;
      logininfo.otp_type = 'validate';
      this.ApiService.apirequest('otpVerification', logininfo).subscribe(data => {
        if (data) {
          let response = data.json();
          if (response.status) {
            this.ApiService.apirequest('getAuthenticationToken', {}).subscribe(token => {
              var expirationMS = 350 * 60 * 1000;
              var record = { timestamp: new Date().getTime() + expirationMS }
              localStorage.setItem('expire_check', JSON.stringify(record));
              localStorage.setItem('accessToken', response.accessToken);
              localStorage.setItem('secretToken', response.secretToken);
              localStorage.setItem('token', token.json().access_token);
              this.successAnimation();
              this.destroySuccess(3000).then(() => { this.anim.stop(); this.router.navigate(['/addpolicy']); });
              this.errorFlag = false;
            });
          }
          else {
            this.errorFlag = true;
            this.destroySuccess(9000).then(() => { this.errorFlag = false; });
          }
        }
        this.optstart = false;
      });
    }
    if (element == null)  // check if its null
      return;
    else
      element.focus();   // focus if not null     
  }
  resentotp() {
    this.loader = true;
    var logininfo = JSON.parse(localStorage.getItem('logindata'));
    logininfo.otpText = 'resend';
    logininfo.otp_type = 'resend';
    this.ApiService.apirequest('otpVerification', logininfo).subscribe(data => {
      this.loader = false;
    });
  }
  // only number will accept
  validateNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
