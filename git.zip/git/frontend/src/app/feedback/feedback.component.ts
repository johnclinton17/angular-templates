/*
 * aegonlife - v1.0.0 - 2019
 * @author aeonlife Insurance
 * feedback.component.ts
 * Description: get Feedbacks from users
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit } from '@angular/core';
import { Router, RouterModule, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ApiService } from './../api/api.service';
import { DeviceDetectorService } from 'ngx-device-detector';

import { Location } from '@angular/common';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  public lottieConfig: Object;
  private anim: any;
  elementSad: any ;
  elementOkay : any;
  elementLove : any;
  message: string;
  ratings: string;
  decrypted_id: any;
  requestMessage: string;
  deviceInfo : any  ;
  clientName: string;
  policynum: string;
  mobileNumber: any;
  previousUrl: string;
  constructor(private deviceService: DeviceDetectorService, private ApiService: ApiService, private router: Router, ) {
    this.lottieConfig = {
      path: 'assets/icons/animation-json/1708-success.json',
      renderer: 'canvas',
      autoplay: false,
      loop: false
    };
    this.epicFunction();
  }
  handleAnimation(anim: any): void {
    this.anim = anim;
  }
  // get the device info
  epicFunction(): void {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }
  ngOnInit() {
    this.requestMessage = localStorage.getItem('message');
    this.elementSad = document.getElementById("sad");
    this.elementOkay = document.getElementById("okay");
    this.elementLove = document.getElementById("love");
    // partyid
    this.decrypted_id = this.ApiService.get( localStorage.getItem('partyid'));
    // party name
    this.clientName = this.ApiService.get( localStorage.getItem('userDetails'));
    // policy number
    this.policynum = this.ApiService.get( localStorage.getItem('policynum'));
    // contact number
    this.mobileNumber = this.ApiService.get( localStorage.getItem('contact'));
    // page url
    this.previousUrl = localStorage.getItem('previousUrl');
  }
  switchSad(param): void {
    this.ratings = param;
    this.elementSad.classList.add("draw");
    this.elementOkay.classList.remove("draw");
    this.elementLove.classList.remove("draw");
  }
  switchOkay(param): void {
    this.ratings = param;
    this.elementSad.classList.remove("draw");
    this.elementOkay.classList.add("draw");
    this.elementLove.classList.remove("draw");
  }
  switchLove(param): void {
    this.ratings = param;
    this.elementSad.classList.remove("draw");
    this.elementOkay.classList.remove("draw");
    this.elementLove.classList.add("draw");
  }
  dealyPromise(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
  }
  // insertfeedback
  submitFeedback() {
    let wrapperElement = document.getElementsByClassName('wrapper') as HTMLCollectionOf<HTMLElement>;
    wrapperElement[0].style.display = 'none';
    let wrapperElement2 = document.getElementsByClassName('wrapper2') as HTMLCollectionOf<HTMLElement>;
    wrapperElement2[0].style.opacity = '1';
    this.anim.play();
    var obj = { 'party_id': this.decrypted_id, 'ratings': this.ratings, "message": this.message, name: this.clientName, email: '', mobile_no: this.mobileNumber, screen_name: this.previousUrl, policy_number: this.policynum, device_type: this.deviceInfo.device, os_type: this.deviceInfo.os, ip_address: '', browser: this.deviceInfo.browser, os_version: this.deviceInfo.os_version, browser_version: this.deviceInfo.browser_version };
    this.ApiService.apirequest('insertfeedback', obj).subscribe(data => {
      if (data.json().message == 'inserted') {
        this.dealyPromise(3000).then(() => { this.router.navigate(['/home']); })
      }
      else {
        // console.log('Something went wrong!');
      }
    })
  }
}
