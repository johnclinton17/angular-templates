import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktophome',
  templateUrl: './desktophome.component.html',
  styleUrls: ['./desktophome.component.css']
})
export class DesktophomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
