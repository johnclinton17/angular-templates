/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * updateaccount.component.ts
 * Description: update contacts
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit {

  constructor(private ApiService: ApiService, private route: ActivatedRoute, private router: Router) { }
clientName;
prolicyDetail : any;
policyName;
  ngOnInit() {
    this.prolicyDetail={};
this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": "GS5574445251941"}).subscribe(data => {
        this.prolicyDetail = data.json();
        this.policyName = this.prolicyDetail.product.name;
    })
  var decrypted = this.ApiService.get('123456$#@$^@1ERF', localStorage.getItem('userDetails'));
this.clientName = decrypted;
  }

neviagteToProfile(type){
	this.router.navigate(['/updateprofile',type]);
}



}
