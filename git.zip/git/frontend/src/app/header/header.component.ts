/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * header.component.ts
 * Description: Menu 
 * Copyright (c) 2019 aegonlife Insurance
 */
//import all dependency file
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponsiveService } from '../responsive.service';
import { NgNavigatorShareService } from 'ng-navigator-share';
import { ApiService } from './../api/api.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  private ngNavigatorShareService: NgNavigatorShareService;
  public isMobile: Boolean;
  mobileNumber;
  clientName;
  constructor(private ApiService: ApiService, private router: Router, ngNavigatorShareService: NgNavigatorShareService, private responsiveService: ResponsiveService) { this.ngNavigatorShareService = ngNavigatorShareService; }
  ngOnInit() {
    var decryptedName = this.ApiService.get( localStorage.getItem('userDetails'));
    this.clientName = decryptedName;
    var mobileNoDecrypted = this.ApiService.get( localStorage.getItem('contact'));
    this.mobileNumber = mobileNoDecrypted;
    // resize event
    this.onResize();
    this.responsiveService.checkWidth();
  }
  // resize fucntion
  onResize(): void  {
    this.responsiveService.getMobileStatus().subscribe(isMobile => {
      this.isMobile = isMobile;
    });
  }
  myFunction(): void  {
    var x = document.getElementById("myDIV");
    if (x.innerText === "English") {
      x.innerText = "हिंदी";
    } else {
      x.innerText = "English";
    }
  }
  logOut(): void  {
    this.router.navigate(['/login']);
    localStorage.removeItem('token');
    localStorage.removeItem('expirecheck');
  }
}
