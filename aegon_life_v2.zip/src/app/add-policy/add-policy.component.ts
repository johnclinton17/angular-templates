import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router, RouterModule } from '@angular/router';
@Component({
  selector: 'app-add-policy',
  templateUrl: './add-policy.component.html',
  styleUrls: ['./add-policy.component.css']
})
export class AddPolicyComponent implements OnInit {

  constructor(private ApiService: ApiService, private router: Router) { }
userDetails:any;
token;
day;
month;
year;
policyNumber;
prolicyDetail;
errorFlag = false;
  ngOnInit() {
 this.token=localStorage.getItem('token');
  }
  // PA1GNUE457EP558

getPolciy(){
	this.ApiService.apirequest('getPolicyBypolicyNumber',{"policyNumber": this.policyNumber,"token" : this.token}).subscribe(data => {
      console.log(data.json().statusCode)
       if(data.json().statusCode){
        this.router.navigate(['/login']); 
       }else{
        this.prolicyDetail = data.json();
        let encypted =this.ApiService.set('123456$#@$^@1ERF', this.policyNumber);
   		localStorage.setItem('policynum',encypted);
        let partyid = this.prolicyDetail.insured.id;

      this.userDetail(partyid)
       }
    })
  }



  userDetail(partyid){
  	 this.ApiService.apirequest('getuserCardDetails',{"token" : this.token ,"partyid" : partyid}).subscribe(data => {
   if(data.json().statusCode){
        this.router.navigate(['/login']); 
       }else{
  this.userDetails = data.json();
  console.log(this.userDetails.dateOfBirth);
  let dob = this.userDetails.dateOfBirth;
  this.compareDate(dob);
}
  })

  	}

 validatePassKey(event:any,id,length) {
 	var target = event.srcElement;
     var textLength = target.value.length;
  if (textLength >= length){
      document.getElementById(id + 1).focus();
  }
}

compareDate(dob){
	console.log(this.year , this.month , this.day);  
       var clienDob = new Date(dob);
       let dobdate = clienDob.getDate();
       let dobMonth = clienDob.getMonth();
       let dobYear = clienDob.getFullYear();
 		let dateOfBirth = + new Date(dobYear,dobMonth , dobdate).getTime();
       var dateInput = + new Date(this.year , this.month , this.day).getTime();  
       if (dateOfBirth == dateInput) {  
            this.router.navigate(['/home']); 
        }else {  
           this.errorFlag = true;
           this.destroyError(9000).then(() => {this.errorFlag = false;});
        }  
    }  


// dateOfBirth: "1990-03-19T00:00:00.000+0000"

destroyError(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
}
